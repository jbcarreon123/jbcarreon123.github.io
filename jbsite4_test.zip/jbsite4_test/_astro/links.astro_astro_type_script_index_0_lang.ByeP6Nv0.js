import"https://palette.nekoweb.org/webring.js";
