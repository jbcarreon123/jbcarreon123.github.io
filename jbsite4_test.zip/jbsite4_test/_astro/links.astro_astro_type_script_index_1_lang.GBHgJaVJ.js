import"https://astracelestine.nekoweb.org/webring/tropical-rice-bowl/widgettext.js";
